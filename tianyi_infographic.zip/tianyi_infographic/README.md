infographic-project/
│
├── index.html            # Main page
│
├── css/
│   └── style.css         # Main CSS file
│
├── js/
│   └── script.js         # Main JavaScript file
│
└── pages/
    ├── subpage1.html     # Subpage 1
    ├── subpage2.html     # Subpage 2
    ├── subpage3.html     # Subpage 3
    └── subpage4.html     # Subpage 4
